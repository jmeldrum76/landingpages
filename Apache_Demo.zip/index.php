<!DOCTYPE html>

<?php

// Extracting required certificate details
$commonName = $_SERVER['SSL_SERVER_S_DN_CN'] ?? 'Unknown';
$organization = $_SERVER['SSL_SERVER_S_DN_O'] ?? 'Unknown';
$serialNumber = $_SERVER['SSL_SERVER_M_SERIAL'] ?? 'Unknown';
$validTo = $_SERVER['SSL_SERVER_V_END'] ?? 'Unknown';

?>

<!-- CSS Styles -->
<style>
.overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent black */
    color: white;
    z-index: 1000; /* Ensure it's on top of other content */
    padding: 10px 0;
    text-align: left; 
    font-family: Arial, sans-serif;
}

.overlay div {
    max-width: 900px;
    margin: 0 auto;
    display: flex;
    padding: 2px 20px; /* Adjust as necessary */
}

.column1 {
    flex-basis: 70%;  /* Take up approximately 70% of the parent width */
    text-align: left; /* Right align the labels */
    padding-right: 20px; /* Add some spacing between the two columns */
}

.column2 {
    flex-basis: 70%;  /* Take up approximately 30% of the parent width */
    text-align: left; /* Left align the data */
}
</style>

<!-- Display Certificate Details -->
<div class="overlay">
    <div>
        <span class="column1">Certificate Common Name (CN):</span>
        <span class="column2"><?php echo $commonName; ?></span>
    </div>
    <div>
        <span class="column1">Organization (O):</span>
        <span class="column2"><?php echo $organization; ?></span>
    </div>
    <div>
        <span class="column1">Certificate Serial Number:</span>
        <span class="column2"><?php echo $serialNumber; ?></span>
    </div>
    <div>
        <span class="column1">Valid To:</span>
        <span class="column2"><?php echo $validTo; ?></span>
    </div>
</div>

<!-- ... Rest of your website's content ... -->

<html lang="en" style="--inner1Vh: 12.87px; --sbw: 0px;"><head><!-- base href="https://jmeldrum.my.canva.site/copy-of-the-venafi-control-plane/" --><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Apache Demo</title><meta name="description" content=""><link rel="icon" href="https://jmeldrum.my.canva.site/copy-of-the-venafi-control-plane/26387fa4f5b1e3f7b6217b27d79bf264.png" type="image/png" sizes="16x16"><link rel="icon" href="https://jmeldrum.my.canva.site/copy-of-the-venafi-control-plane/2d0b56e7e51cf11036ad8734bdb67e2d.png" type="image/png" sizes="32x32"><link rel="apple-touch-icon" href="https://jmeldrum.my.canva.site/copy-of-the-venafi-control-plane/725b756a69a7d4c235070e51acd85560.png" sizes="180x180"><meta property="og:type" content="website"><meta property="og:url" content="https://jmeldrum.my.canva.site/copy-of-the-venafi-control-plane"><meta property="og:title" content="Apache Demo"><meta property="og:image" content="https://jmeldrum.my.canva.site/copy-of-the-venafi-control-plane/60d3d940d03babb7590d0fa8ae571cd9.png"><meta property="og:image:type" content="image/png"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta name="twitter:card" content="summary_large_image"><style>:root {  --ffsd: 0px;  --1vw: calc((100vw - var(--sbw, 0px)) / 100);  --1vh: var(--inner1Vh, 1vh);}@media (prefers-reduced-motion: reduce) {  .animated {    animation: none !important;  }}html {  zoom: var(--rzf, 1);  font-size: max(calc(min(var(--1vw, 1vw), 13.66px) * var(--rfso, 1)), var(--minfs, 0px));  -webkit-text-size-adjust: 100%;  scroll-behavior: smooth;}body {  font-size: calc(1rem * var(--bfso, 1));}body, html, p, ul, ol, li {  margin: 0;  padding: 0;  font-synthesis: none;  font-kerning: none;  font-variant-ligatures: none;  font-feature-settings: "kern" 0, "calt" 0, "liga" 0, "clig" 0, "dlig" 0, "hlig" 0;  font-family: unset;  -webkit-font-smoothing: subpixel-antialiased;  -moz-osx-font-smoothing: grayscale;  text-rendering: geometricprecision;  white-space: normal;}li {  text-align: unset;}a {  text-decoration: none;  color: inherit;}img {  -webkit-user-drag: none;  -moz-user-drag: none;  -o-user-drag: none;  user-drag: none;  -webkit-touch-callout: none;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/127f1f8810cbf9b7088c5a9bd8005fe3.woff2);  font-style: normal;  font-weight: 400;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/569086aaaf15784082758d6a39803022.woff2);  font-style: normal;  font-weight: 700;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/7dc66bd302ac04c9bf96320650ec1e6d.woff2);  font-style: italic;  font-weight: 400;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/86d1bc8611ae370c27a8dc6f32c38066.woff2);  font-style: italic;  font-weight: 700;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/127f1f8810cbf9b7088c5a9bd8005fe3.woff2);  font-style: normal;  font-weight: 100;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/7dc66bd302ac04c9bf96320650ec1e6d.woff2);  font-style: italic;  font-weight: 100;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/127f1f8810cbf9b7088c5a9bd8005fe3.woff2);  font-style: normal;  font-weight: 200;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/7dc66bd302ac04c9bf96320650ec1e6d.woff2);  font-style: italic;  font-weight: 200;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/127f1f8810cbf9b7088c5a9bd8005fe3.woff2);  font-style: normal;  font-weight: 300;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/7dc66bd302ac04c9bf96320650ec1e6d.woff2);  font-style: italic;  font-weight: 300;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/127f1f8810cbf9b7088c5a9bd8005fe3.woff2);  font-style: normal;  font-weight: 500;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/7dc66bd302ac04c9bf96320650ec1e6d.woff2);  font-style: italic;  font-weight: 500;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/569086aaaf15784082758d6a39803022.woff2);  font-style: normal;  font-weight: 600;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/86d1bc8611ae370c27a8dc6f32c38066.woff2);  font-style: italic;  font-weight: 600;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/569086aaaf15784082758d6a39803022.woff2);  font-style: normal;  font-weight: 800;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/86d1bc8611ae370c27a8dc6f32c38066.woff2);  font-style: italic;  font-weight: 800;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/569086aaaf15784082758d6a39803022.woff2);  font-style: normal;  font-weight: 900;}@font-face {  font-family: YAEp1FLgsF4-0;  src: url(fonts/86d1bc8611ae370c27a8dc6f32c38066.woff2);  font-style: italic;  font-weight: 900;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/f8f199f09526f79e87644ed227e0f651.woff2);  font-style: normal;  font-weight: 400;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/98c4d2c0223fc8474641c77f923528e9.woff2);  font-style: normal;  font-weight: 700;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/d257a7100844bc3f98c9021168b6249e.woff2);  font-style: italic;  font-weight: 400;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/1060345c54d396e76d73f1da7ee200bd.woff2);  font-style: italic;  font-weight: 700;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/f8f199f09526f79e87644ed227e0f651.woff2);  font-style: normal;  font-weight: 100;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/d257a7100844bc3f98c9021168b6249e.woff2);  font-style: italic;  font-weight: 100;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/f8f199f09526f79e87644ed227e0f651.woff2);  font-style: normal;  font-weight: 200;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/d257a7100844bc3f98c9021168b6249e.woff2);  font-style: italic;  font-weight: 200;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/f8f199f09526f79e87644ed227e0f651.woff2);  font-style: normal;  font-weight: 300;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/d257a7100844bc3f98c9021168b6249e.woff2);  font-style: italic;  font-weight: 300;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/f8f199f09526f79e87644ed227e0f651.woff2);  font-style: normal;  font-weight: 500;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/d257a7100844bc3f98c9021168b6249e.woff2);  font-style: italic;  font-weight: 500;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/98c4d2c0223fc8474641c77f923528e9.woff2);  font-style: normal;  font-weight: 600;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/1060345c54d396e76d73f1da7ee200bd.woff2);  font-style: italic;  font-weight: 600;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/98c4d2c0223fc8474641c77f923528e9.woff2);  font-style: normal;  font-weight: 800;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/1060345c54d396e76d73f1da7ee200bd.woff2);  font-style: italic;  font-weight: 800;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/98c4d2c0223fc8474641c77f923528e9.woff2);  font-style: normal;  font-weight: 900;}@font-face {  font-family: YACgEZ1cb1Q-0;  src: url(fonts/1060345c54d396e76d73f1da7ee200bd.woff2);  font-style: italic;  font-weight: 900;}@media (max-width: 375px) {  #bNxnjqXzmkjnccmF {    grid-area: 2 / 2 / 3 / 3;    position: relative;  }  #ejaCnj6HaBByHQC5 {    grid-template-columns: 0 100%;    grid-template-rows: 0 100%;  }  #SLPnGYLVt7fXAhsW {    grid-area: 2 / 2 / 5 / 5;    position: absolute;    top: 0px;    bottom: 0px;    left: 0rem;    right: 0rem;  }  #hyZbdyIf9yYVtIlM {    grid-area: 3 / 3 / 4 / 4;    position: relative;  }  #HpwppDfS4c6jER9L {    grid-template-columns: 0 77.04494408rem 17.95424902rem 5.0008069rem;    grid-template-rows: 0 minmax(0.73782001rem, max-content) minmax(6.84505744rem, max-content) minmax(0.73782001rem, max-content);  }  #wtJcBocQDtz1QF1B {    grid-area: 2 / 2 / 4 / 9;    position: relative;  }  #uNw6v9c2I4OCExG5 {    grid-area: 3 / 3 / 5 / 6;    position: relative;    clip-path: polygon(calc(0% + 0%) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc(100% - ((0 * 26.22756312rem) + 0%)), calc(0% + 0%) calc(100% - ((0 * 26.22756312rem) + 0%)));    margin-left: 0%;    margin-right: 0%;    margin-bottom: 0%;    margin-top: -2.89749417%;  }  #RM31140YFFukPEqA {    font-size: calc(5.49964907em - var(--ffsd));  }  #rVuDTY2BvOJHpuqZ {    --first-font-size: 5.49964907em;    --last-font-size: var(--first-font-size);    margin-top: calc(var(--first-font-size) * 0.05);    margin-bottom: calc(var(--last-font-size) * 0.05);  }  #Sy8O6R7vT0kojtII {    min-width: 69.36810268rem;  }  #WRcs7mixzyz9JEfY {    grid-area: 2 / 2 / 3 / 4;    position: relative;  }  #ssHcvm57c4k7sGFK {    font-size: calc(1.80808931em - var(--ffsd));  }  #yK42fYBidfOo7R7k {    font-size: calc(1.80808931em - var(--ffsd));  }  #UjDkFJSRDlk7iExs {    --first-font-size: 1.80808931em;    --last-font-size: var(--first-font-size);    margin-top: 0;    margin-bottom: 0;  }  #wC70GHU6PrMli2JY {    min-width: 69.36810268rem;  }  #UkIErEewEIN7zxtk {    grid-area: 4 / 3 / 5 / 5;    position: relative;  }  #lo86JgckCM3k48nG {    grid-template-columns: 0 0 69.23476934rem 0;    grid-template-rows: 0 minmax(6.59580786rem, max-content) minmax(1.55800088rem, max-content) minmax(4.24597365rem, max-content);  }  #ARWsy6Ub7mQjTKU1 {    grid-area: 6 / 5 / 7 / 8;    position: relative;  }  #pUeRJlhGl3BXjyvz {    grid-area: 2 / 5 / 11 / 7;    position: relative;    margin-left: 0%;    margin-right: 0%;    margin-bottom: -323.60935499%;    margin-top: -323.60935499%;  }  #WaVP7Y3VDg20AlM0 {    grid-area: 5 / 2 / 9 / 3;    position: relative;  }  #cecPwCtAY1v73YAY {    grid-area: 6 / 4 / 8 / 6;    position: relative;  }  #zbNaYWBcZDf8Qapn {    grid-area: 4 / 8 / 7 / 9;    position: relative;  }  #t4VZOlJbFtyMV50z {    grid-area: 3 / 10 / 10 / 11;    position: relative;  }  #zEeMDi2gxAE2fw8f {    grid-template-columns: 0 19.84471818rem 1.24336652rem 6.50245648rem 9.05745425rem 0.05764505rem 1.18572148rem 16.28042228rem 1.24336652rem 9.92181865rem;    grid-template-rows: 0 minmax(2.19127179rem, max-content) minmax(0.33424596rem, max-content) minmax(0.28815607rem, max-content) minmax(0.03415735rem, max-content) minmax(2.84764389rem, max-content) 0 minmax(0.03415735rem, max-content) minmax(0.62240204rem, max-content) minmax(2.76306485rem, max-content);  }  #p0KEX1uxIUTFd0aJ {    grid-area: 8 / 4 / 9 / 7;    position: relative;  }  #gbEFzgMldUlBMJdS {    grid-template-columns: 0 0.59305553rem 17.25885364rem 2.37741737rem 6.59129212rem 56.36825992rem 6.27521731rem 10.53590412rem;    grid-template-rows: 0 0 minmax(8.32069746rem, max-content) minmax(0.75994211rem, max-content) minmax(7.68027776rem, max-content) minmax(12.39978239rem, max-content) minmax(15.78883966rem, max-content) minmax(9.11509929rem, max-content) minmax(2.15790891rem, max-content);  }  #page-1 {    min-height: calc(100 * var(--1vh, 1vh));  }}@media (min-width: 375.05px) and (max-width: 480px) {  #bNxnjqXzmkjnccmF {    grid-area: 2 / 2 / 3 / 3;    position: relative;  }  #ejaCnj6HaBByHQC5 {    grid-template-columns: 0 100%;    grid-template-rows: 0 100%;  }  #SLPnGYLVt7fXAhsW {    grid-area: 2 / 2 / 5 / 5;    position: absolute;    top: 0px;    bottom: 0px;    left: 0rem;    right: 0rem;  }  #hyZbdyIf9yYVtIlM {    grid-area: 3 / 3 / 4 / 4;    position: relative;  }  #HpwppDfS4c6jER9L {    grid-template-columns: 0 77.04494408rem 17.95424902rem 5.0008069rem;    grid-template-rows: 0 minmax(0.73782001rem, max-content) minmax(6.84505744rem, max-content) minmax(0.73782001rem, max-content);  }  #wtJcBocQDtz1QF1B {    grid-area: 2 / 2 / 4 / 9;    position: relative;  }  #uNw6v9c2I4OCExG5 {    grid-area: 3 / 3 / 5 / 6;    position: relative;    clip-path: polygon(calc(0% + 0%) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc(100% - ((0 * 26.22756312rem) + 0%)), calc(0% + 0%) calc(100% - ((0 * 26.22756312rem) + 0%)));    margin-left: 0%;    margin-right: 0%;    margin-bottom: 0%;    margin-top: -2.89749417%;  }  #RM31140YFFukPEqA {    font-size: calc(5.49964907em - var(--ffsd));  }  #rVuDTY2BvOJHpuqZ {    --first-font-size: 5.49964907em;    --last-font-size: var(--first-font-size);    margin-top: calc(var(--first-font-size) * 0.05);    margin-bottom: calc(var(--last-font-size) * 0.05);  }  #Sy8O6R7vT0kojtII {    min-width: 69.33893601rem;  }  #WRcs7mixzyz9JEfY {    grid-area: 2 / 2 / 3 / 4;    position: relative;  }  #ssHcvm57c4k7sGFK {    font-size: calc(1.80808931em - var(--ffsd));  }  #yK42fYBidfOo7R7k {    font-size: calc(1.80808931em - var(--ffsd));  }  #UjDkFJSRDlk7iExs {    --first-font-size: 1.80808931em;    --last-font-size: var(--first-font-size);    margin-top: 0;    margin-bottom: 0;  }  #wC70GHU6PrMli2JY {    min-width: 69.33893601rem;  }  #UkIErEewEIN7zxtk {    grid-area: 4 / 3 / 5 / 5;    position: relative;  }  #lo86JgckCM3k48nG {    grid-template-columns: 0 0 69.23476934rem 0;    grid-template-rows: 0 minmax(6.59580786rem, max-content) minmax(1.55800088rem, max-content) minmax(4.24597365rem, max-content);  }  #ARWsy6Ub7mQjTKU1 {    grid-area: 6 / 5 / 7 / 8;    position: relative;  }  #pUeRJlhGl3BXjyvz {    grid-area: 2 / 5 / 11 / 7;    position: relative;    margin-left: 0%;    margin-right: 0%;    margin-bottom: -323.60935499%;    margin-top: -323.60935499%;  }  #WaVP7Y3VDg20AlM0 {    grid-area: 5 / 2 / 9 / 3;    position: relative;  }  #cecPwCtAY1v73YAY {    grid-area: 6 / 4 / 8 / 6;    position: relative;  }  #zbNaYWBcZDf8Qapn {    grid-area: 4 / 8 / 7 / 9;    position: relative;  }  #t4VZOlJbFtyMV50z {    grid-area: 3 / 10 / 10 / 11;    position: relative;  }  #zEeMDi2gxAE2fw8f {    grid-template-columns: 0 19.84471818rem 1.24336652rem 6.50245648rem 9.05745425rem 0.05764505rem 1.18572148rem 16.28042228rem 1.24336652rem 9.92181865rem;    grid-template-rows: 0 minmax(2.19127179rem, max-content) minmax(0.33424596rem, max-content) minmax(0.28815607rem, max-content) minmax(0.03415735rem, max-content) minmax(2.84764389rem, max-content) 0 minmax(0.03415735rem, max-content) minmax(0.62240204rem, max-content) minmax(2.76306485rem, max-content);  }  #p0KEX1uxIUTFd0aJ {    grid-area: 8 / 4 / 9 / 7;    position: relative;  }  #gbEFzgMldUlBMJdS {    grid-template-columns: 0 0.59305553rem 17.25885364rem 2.37741737rem 6.59129212rem 56.36825992rem 6.27521731rem 10.53590412rem;    grid-template-rows: 0 0 minmax(8.32069746rem, max-content) minmax(0.75994211rem, max-content) minmax(7.68027776rem, max-content) minmax(12.39978239rem, max-content) minmax(15.78883966rem, max-content) minmax(9.11509929rem, max-content) minmax(2.15790891rem, max-content);  }  #page-1 {    min-height: calc(100 * var(--1vh, 1vh));  }}@media (min-width: 480.05px) and (max-width: 768px) {  #bNxnjqXzmkjnccmF {    grid-area: 2 / 2 / 3 / 3;    position: relative;  }  #ejaCnj6HaBByHQC5 {    grid-template-columns: 0 100%;    grid-template-rows: 0 100%;  }  #SLPnGYLVt7fXAhsW {    grid-area: 2 / 2 / 5 / 5;    position: absolute;    top: 0px;    bottom: 0px;    left: 0rem;    right: 0rem;  }  #hyZbdyIf9yYVtIlM {    grid-area: 3 / 3 / 4 / 4;    position: relative;  }  #HpwppDfS4c6jER9L {    grid-template-columns: 0 77.04494408rem 17.95424902rem 5.0008069rem;    grid-template-rows: 0 minmax(0.73782001rem, max-content) minmax(6.84505744rem, max-content) minmax(0.73782001rem, max-content);  }  #wtJcBocQDtz1QF1B {    grid-area: 2 / 2 / 4 / 9;    position: relative;  }  #uNw6v9c2I4OCExG5 {    grid-area: 3 / 3 / 5 / 6;    position: relative;    clip-path: polygon(calc(0% + 0%) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc(100% - ((0 * 26.22756312rem) + 0%)), calc(0% + 0%) calc(100% - ((0 * 26.22756312rem) + 0%)));    margin-left: 0%;    margin-right: 0%;    margin-bottom: 0%;    margin-top: -2.89749417%;  }  #RM31140YFFukPEqA {    font-size: calc(5.49964907em - var(--ffsd));  }  #rVuDTY2BvOJHpuqZ {    --first-font-size: 5.49964907em;    --last-font-size: var(--first-font-size);    margin-top: calc(var(--first-font-size) * 0.05);    margin-bottom: calc(var(--last-font-size) * 0.05);  }  #Sy8O6R7vT0kojtII {    min-width: 69.29987351rem;  }  #WRcs7mixzyz9JEfY {    grid-area: 2 / 2 / 3 / 4;    position: relative;  }  #ssHcvm57c4k7sGFK {    font-size: calc(1.80808931em - var(--ffsd));  }  #yK42fYBidfOo7R7k {    font-size: calc(1.80808931em - var(--ffsd));  }  #UjDkFJSRDlk7iExs {    --first-font-size: 1.80808931em;    --last-font-size: var(--first-font-size);    margin-top: 0;    margin-bottom: 0;  }  #wC70GHU6PrMli2JY {    min-width: 69.29987351rem;  }  #UkIErEewEIN7zxtk {    grid-area: 4 / 3 / 5 / 5;    position: relative;  }  #lo86JgckCM3k48nG {    grid-template-columns: 0 0 69.23476934rem 0;    grid-template-rows: 0 minmax(6.59580786rem, max-content) minmax(1.55800088rem, max-content) minmax(4.24597365rem, max-content);  }  #ARWsy6Ub7mQjTKU1 {    grid-area: 6 / 5 / 7 / 8;    position: relative;  }  #pUeRJlhGl3BXjyvz {    grid-area: 2 / 5 / 11 / 7;    position: relative;    margin-left: 0%;    margin-right: 0%;    margin-bottom: -323.60935499%;    margin-top: -323.60935499%;  }  #WaVP7Y3VDg20AlM0 {    grid-area: 5 / 2 / 9 / 3;    position: relative;  }  #cecPwCtAY1v73YAY {    grid-area: 6 / 4 / 8 / 6;    position: relative;  }  #zbNaYWBcZDf8Qapn {    grid-area: 4 / 8 / 7 / 9;    position: relative;  }  #t4VZOlJbFtyMV50z {    grid-area: 3 / 10 / 10 / 11;    position: relative;  }  #zEeMDi2gxAE2fw8f {    grid-template-columns: 0 19.84471818rem 1.24336652rem 6.50245648rem 9.05745425rem 0.05764505rem 1.18572148rem 16.28042228rem 1.24336652rem 9.92181865rem;    grid-template-rows: 0 minmax(2.19127179rem, max-content) minmax(0.33424596rem, max-content) minmax(0.28815607rem, max-content) minmax(0.03415735rem, max-content) minmax(2.84764389rem, max-content) 0 minmax(0.03415735rem, max-content) minmax(0.62240204rem, max-content) minmax(2.76306485rem, max-content);  }  #p0KEX1uxIUTFd0aJ {    grid-area: 8 / 4 / 9 / 7;    position: relative;  }  #gbEFzgMldUlBMJdS {    grid-template-columns: 0 0.59305553rem 17.25885364rem 2.37741737rem 6.59129212rem 56.36825992rem 6.27521731rem 10.53590412rem;    grid-template-rows: 0 0 minmax(8.32069746rem, max-content) minmax(0.75994211rem, max-content) minmax(7.68027776rem, max-content) minmax(12.39978239rem, max-content) minmax(15.78883966rem, max-content) minmax(9.11509929rem, max-content) minmax(2.15790891rem, max-content);  }  #page-1 {    min-height: calc(100 * var(--1vh, 1vh));  }}@media (min-width: 768.05px) and (max-width: 1024px) {  #bNxnjqXzmkjnccmF {    grid-area: 2 / 2 / 3 / 3;    position: relative;  }  #ejaCnj6HaBByHQC5 {    grid-template-columns: 0 100%;    grid-template-rows: 0 100%;  }  #SLPnGYLVt7fXAhsW {    grid-area: 2 / 2 / 5 / 5;    position: absolute;    top: 0px;    bottom: 0px;    left: 0rem;    right: 0rem;  }  #hyZbdyIf9yYVtIlM {    grid-area: 3 / 3 / 4 / 4;    position: relative;  }  #HpwppDfS4c6jER9L {    grid-template-columns: 0 77.04494408rem 17.95424902rem 5.0008069rem;    grid-template-rows: 0 minmax(0.73782001rem, max-content) minmax(6.84505744rem, max-content) minmax(0.73782001rem, max-content);  }  #wtJcBocQDtz1QF1B {    grid-area: 2 / 2 / 4 / 9;    position: relative;  }  #uNw6v9c2I4OCExG5 {    grid-area: 3 / 3 / 5 / 6;    position: relative;    clip-path: polygon(calc(0% + 0%) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc(100% - ((0 * 26.22756312rem) + 0%)), calc(0% + 0%) calc(100% - ((0 * 26.22756312rem) + 0%)));    margin-left: 0%;    margin-right: 0%;    margin-bottom: 0%;    margin-top: -2.89749417%;  }  #RM31140YFFukPEqA {    font-size: calc(5.49964907em - var(--ffsd));  }  #rVuDTY2BvOJHpuqZ {    --first-font-size: 5.49964907em;    --last-font-size: var(--first-font-size);    margin-top: calc(var(--first-font-size) * 0.05);    margin-bottom: calc(var(--last-font-size) * 0.05);  }  #Sy8O6R7vT0kojtII {    min-width: 69.28359747rem;  }  #WRcs7mixzyz9JEfY {    grid-area: 2 / 2 / 3 / 4;    position: relative;  }  #ssHcvm57c4k7sGFK {    font-size: calc(1.80808931em - var(--ffsd));  }  #yK42fYBidfOo7R7k {    font-size: calc(1.80808931em - var(--ffsd));  }  #UjDkFJSRDlk7iExs {    --first-font-size: 1.80808931em;    --last-font-size: var(--first-font-size);    margin-top: 0;    margin-bottom: 0;  }  #wC70GHU6PrMli2JY {    min-width: 69.28359747rem;  }  #UkIErEewEIN7zxtk {    grid-area: 4 / 3 / 5 / 5;    position: relative;  }  #lo86JgckCM3k48nG {    grid-template-columns: 0 0 69.23476934rem 0;    grid-template-rows: 0 minmax(6.59580786rem, max-content) minmax(1.55800088rem, max-content) minmax(4.24597365rem, max-content);  }  #ARWsy6Ub7mQjTKU1 {    grid-area: 6 / 5 / 7 / 8;    position: relative;  }  #pUeRJlhGl3BXjyvz {    grid-area: 2 / 5 / 11 / 7;    position: relative;    margin-left: 0%;    margin-right: 0%;    margin-bottom: -323.60935499%;    margin-top: -323.60935499%;  }  #WaVP7Y3VDg20AlM0 {    grid-area: 5 / 2 / 9 / 3;    position: relative;  }  #cecPwCtAY1v73YAY {    grid-area: 6 / 4 / 8 / 6;    position: relative;  }  #zbNaYWBcZDf8Qapn {    grid-area: 4 / 8 / 7 / 9;    position: relative;  }  #t4VZOlJbFtyMV50z {    grid-area: 3 / 10 / 10 / 11;    position: relative;  }  #zEeMDi2gxAE2fw8f {    grid-template-columns: 0 19.84471818rem 1.24336652rem 6.50245648rem 9.05745425rem 0.05764505rem 1.18572148rem 16.28042228rem 1.24336652rem 9.92181865rem;    grid-template-rows: 0 minmax(2.19127179rem, max-content) minmax(0.33424596rem, max-content) minmax(0.28815607rem, max-content) minmax(0.03415735rem, max-content) minmax(2.84764389rem, max-content) 0 minmax(0.03415735rem, max-content) minmax(0.62240204rem, max-content) minmax(2.76306485rem, max-content);  }  #p0KEX1uxIUTFd0aJ {    grid-area: 8 / 4 / 9 / 7;    position: relative;  }  #gbEFzgMldUlBMJdS {    grid-template-columns: 0 0.59305553rem 17.25885364rem 2.37741737rem 6.59129212rem 56.36825992rem 6.27521731rem 10.53590412rem;    grid-template-rows: 0 0 minmax(8.32069746rem, max-content) minmax(0.75994211rem, max-content) minmax(7.68027776rem, max-content) minmax(12.39978239rem, max-content) minmax(15.78883966rem, max-content) minmax(9.11509929rem, max-content) minmax(2.15790891rem, max-content);  }  #page-1 {    min-height: calc(100 * var(--1vh, 1vh));  }}@media (min-width: 1024.05px) {  #bNxnjqXzmkjnccmF {    grid-area: 2 / 2 / 3 / 3;    position: relative;  }  #ejaCnj6HaBByHQC5 {    grid-template-columns: 0 100%;    grid-template-rows: 0 100%;  }  #SLPnGYLVt7fXAhsW {    grid-area: 2 / 2 / 5 / 5;    position: absolute;    top: 0px;    bottom: 0px;    left: calc(min(1366px - 100vw, 0px) / 2);    right: calc(min(1366px - 100vw, 0px) / 2);  }  #hyZbdyIf9yYVtIlM {    grid-area: 3 / 3 / 4 / 4;    position: relative;  }  #HpwppDfS4c6jER9L {    grid-template-columns: 0 77.04494408rem 17.95424902rem 5.0008069rem;    grid-template-rows: 0 minmax(0.73782001rem, max-content) minmax(6.84505744rem, max-content) minmax(0.73782001rem, max-content);  }  #wtJcBocQDtz1QF1B {    grid-area: 2 / 2 / 4 / 9;    position: relative;  }  #uNw6v9c2I4OCExG5 {    grid-area: 3 / 3 / 5 / 6;    position: relative;    clip-path: polygon(calc(0% + 0%) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc((0.02897494 * 26.22756312rem) + 0%), calc(100% - (0% + 0%)) calc(100% - ((0 * 26.22756312rem) + 0%)), calc(0% + 0%) calc(100% - ((0 * 26.22756312rem) + 0%)));    margin-left: 0%;    margin-right: 0%;    margin-bottom: 0%;    margin-top: -2.89749417%;  }  #RM31140YFFukPEqA {    font-size: calc(5.49964907em - var(--ffsd));  }  #rVuDTY2BvOJHpuqZ {    --first-font-size: 5.49964907em;    --last-font-size: var(--first-font-size);    margin-top: calc(var(--first-font-size) * 0.05);    margin-bottom: calc(var(--last-font-size) * 0.05);  }  #Sy8O6R7vT0kojtII {    min-width: 69.27137257rem;  }  #WRcs7mixzyz9JEfY {    grid-area: 2 / 2 / 3 / 4;    position: relative;  }  #ssHcvm57c4k7sGFK {    font-size: calc(1.80808931em - var(--ffsd));  }  #yK42fYBidfOo7R7k {    font-size: calc(1.80808931em - var(--ffsd));  }  #UjDkFJSRDlk7iExs {    --first-font-size: 1.80808931em;    --last-font-size: var(--first-font-size);    margin-top: 0;    margin-bottom: 0;  }  #wC70GHU6PrMli2JY {    min-width: 69.27137257rem;  }  #UkIErEewEIN7zxtk {    grid-area: 4 / 3 / 5 / 5;    position: relative;  }  #lo86JgckCM3k48nG {    grid-template-columns: 0 0 69.23476934rem 0;    grid-template-rows: 0 minmax(6.59580786rem, max-content) minmax(1.55800088rem, max-content) minmax(4.24597365rem, max-content);  }  #ARWsy6Ub7mQjTKU1 {    grid-area: 6 / 5 / 7 / 8;    position: relative;  }  #pUeRJlhGl3BXjyvz {    grid-area: 2 / 5 / 11 / 7;    position: relative;    margin-left: 0%;    margin-right: 0%;    margin-bottom: -323.60935499%;    margin-top: -323.60935499%;  }  #WaVP7Y3VDg20AlM0 {    grid-area: 5 / 2 / 9 / 3;    position: relative;  }  #cecPwCtAY1v73YAY {    grid-area: 6 / 4 / 8 / 6;    position: relative;  }  #zbNaYWBcZDf8Qapn {    grid-area: 4 / 8 / 7 / 9;    position: relative;  }  #t4VZOlJbFtyMV50z {    grid-area: 3 / 10 / 10 / 11;    position: relative;  }  #zEeMDi2gxAE2fw8f {    grid-template-columns: 0 19.84471818rem 1.24336652rem 6.50245648rem 9.05745425rem 0.05764505rem 1.18572148rem 16.28042228rem 1.24336652rem 9.92181865rem;    grid-template-rows: 0 minmax(2.19127179rem, max-content) minmax(0.33424596rem, max-content) minmax(0.28815607rem, max-content) minmax(0.03415735rem, max-content) minmax(2.84764389rem, max-content) 0 minmax(0.03415735rem, max-content) minmax(0.62240204rem, max-content) minmax(2.76306485rem, max-content);  }  #p0KEX1uxIUTFd0aJ {    grid-area: 8 / 4 / 9 / 7;    position: relative;  }  #gbEFzgMldUlBMJdS {    grid-template-columns: 0 0.59305553rem 17.25885364rem 2.37741737rem 6.59129212rem 56.36825992rem 6.27521731rem 10.53590412rem;    grid-template-rows: 0 0 minmax(8.32069746rem, max-content) minmax(0.75994211rem, max-content) minmax(7.68027776rem, max-content) minmax(12.39978239rem, max-content) minmax(15.78883966rem, max-content) minmax(9.11509929rem, max-content) minmax(2.15790891rem, max-content);  }  #page-1 {    min-height: calc(100 * var(--1vh, 1vh));  }}@keyframes pulse {  0% {    background-color: rgba(226, 226, 226, 0.05);  }  50% {    background-color: rgba(226, 226, 226, 0.1);  }  100% {    background-color: rgba(226, 226, 226, 0.05);  }}@keyframes breathe-RIGHT-4f6e5b1d-2ac8-46c9-837b-a48731484306 {  0% {    transform: scale(0.831);    animation-timing-function: linear;  }  50% {    transform: scale(0.9886);    animation-timing-function: linear;  }  100% {    transform: scale(1);  }}@keyframes wipe-RIGHT-7116b0ee-7e21-4ef5-9477-5ac50eca7f84 {  0% {    clip-path: inset(-60% 100% -60% -10%);    animation-timing-function: cubic-bezier(0.31, 0.92, 0.6, 1.01);  }  100% {    clip-path: inset(-60% -10% -60% -10%);  }}@keyframes linear_fade {  0% {    opacity: 0.0;  }  100% {    opacity: 1.0;  }}@keyframes wipe-RIGHT-a0f32f33-7085-46ac-9f53-6c26e04e4b9e {  0% {    clip-path: inset(-60% 100% -60% -10%);    animation-timing-function: cubic-bezier(0.31, 0.92, 0.6, 1.01);  }  100% {    clip-path: inset(-60% -10% -60% -10%);  }}</style><noscript>  <style>    .animated {      animation-play-state: running !important;    }    @keyframes pulse {}  </style></noscript><script nonce="">!function(){"use strict";function t(t,n){let e;return(...o)=>{clearTimeout(e),e=setTimeout((()=>{t(...o)}),n)}}class n{constructor(){this.callbacks=[],window.addEventListener("DOMContentLoaded",(()=>this.onDOMContentLoaded()))}onDOMContentLoaded(){this.callbacks.sort(((t,n)=>t.priority-n.priority)).forEach((({callback:t})=>t()))}runOnLoad(t){"loading"===document.readyState?this.callbacks.push(t):t.callback()}}function e(t,e=Number.MAX_VALUE){var o;(window.canva_scriptExecutor=null!==(o=window.canva_scriptExecutor)&&void 0!==o?o:new n).runOnLoad({callback:t,priority:e})}class o{constructor(t){this.items=[],this.previousWidth=document.documentElement.clientWidth,this.previousHeight=window.innerHeight;const n=t((()=>this.onWindowResize()),100);window.addEventListener("resize",n)}onWindowResize(){const t=document.documentElement.clientWidth,n=window.innerHeight,e=this.previousWidth!==t,o=this.previousHeight!==n;this.items.forEach((t=>{const n=()=>{t.callback(),t.executed=!0};(!t.executed||e&&t.options.runOnWidthChange||o&&t.options.runOnHeightChange)&&n()})),this.previousWidth=t,this.previousHeight=n}runOnResize(t,n){this.items.push({callback:t,options:n,executed:n.runOnLoad}),this.items.sort(((t,n)=>t.options.priority-n.options.priority)),n.runOnLoad&&e(t,n.priority)}}function i(n,e,i=t){var r;(window.canva_debounceResize=null!==(r=window.canva_debounceResize)&&void 0!==r?r:new o(i)).runOnResize(n,{runOnLoad:!1,runOnWidthChange:!0,runOnHeightChange:!1,priority:Number.MAX_VALUE,...e})}const r="--minfs",c="--rzf",u="--rfso",s="--bfso";function a(t,n,e=.001){return Math.abs(t-n)<e}function d(t,n){return window.getComputedStyle(t).getPropertyValue(n)}function l(t,n,e){t.style.setProperty(n,e)}function m(t,n){const e=document.createElement("div");e.style.setProperty(t,n),document.body.append(e);const o=d(e,t);return e.remove(),o}function f(){const t=function(){const t=parseFloat(m("font-size","0.1px"));return t>1?t:0}(),n=function(t){const n=2*Math.max(t,1);return n/parseFloat(m("font-size",`${n}px`))}(t);if(function(t){if(0===t)return;l(document.documentElement,r,`${t}px`),i((()=>{const n=100*t,{clientWidth:e}=document.documentElement;l(document.documentElement,c,n>e?(e/n).toPrecision(4):null)}),{runOnLoad:!0})}(t*Math.max(1,n)),a(n,1))return;const e=a(parseFloat(d(document.documentElement,"font-size")),parseFloat(m("grid-template-columns","1rem")));l(document.documentElement,e?u:s,n.toPrecision(4))}function h(){document.querySelectorAll("img, image, video, svg").forEach((t=>t.addEventListener("contextmenu",(t=>t.preventDefault()))))}const p="--sbw",w="--inner1Vh";function g(t,n,e){t.style.setProperty(n,e)}function v(){g(document.documentElement,w,window.innerHeight/100+"px"),function(){const t=window.innerWidth-document.documentElement.clientWidth;g(document.documentElement,p,t>=0?`${t}px`:null)}()}var y;const E="undefined"!=typeof window?null===(y=window.navigator)||void 0===y?void 0:y.userAgent:void 0;const b=!(!E||(O=E,!O.match(/AppleWebKit\//)||O.match(/Chrome\//)||O.match(/Chromium\//)));var O;function L(){document.querySelectorAll("svg").forEach((t=>t.style.background="url('')"))}let x;function A(){x||(x=Array.from(document.querySelectorAll("foreignObject")).filter((t=>0===t.getBoundingClientRect().width)));const t=function(){const t=document.createElement("div");t.style.fontSize="100vw",document.body.append(t);const n=parseFloat(window.getComputedStyle(t).fontSize);return t.remove(),n/window.innerWidth}();Array.from(x).forEach((n=>function(t){return new Promise(((n,e)=>{const o=t.querySelector("img");o&&!o.complete?(o.addEventListener("load",(()=>n())),o.addEventListener("error",(()=>e()))):n()}))}(n).finally((()=>function(t,n){const e=Array.from(t.children);e.forEach(((t,n)=>{if(t.hasAttribute("data-foreign-object-container"))t.style.transformOrigin="",t.style.transform="";else{const o=document.createElement("div");o.setAttribute("data-foreign-object-container",""),t.insertAdjacentElement("beforebegin",o),t.remove(),o.append(t),e[n]=o}}));const o=t.getScreenCTM();if(!o)return;const{a:i,b:r,c:c,d:u}=o.scale(n);e.forEach((t=>{if(!t.hasAttribute("data-foreign-object-container"))return;const{style:n}=t;n.transformOrigin="0px 0px",n.transform=`matrix(${i}, ${r}, ${c}, ${u}, 0, 0)`}))}(n,t)))))}[function(){e(f)},function(){i(v,{runOnLoad:!0,runOnHeightChange:!0,priority:1})},function(){b&&i(A,{runOnLoad:!0})},function(){b&&e(L)},function(){e(h)}].forEach((t=>t()))}();</script><script nonce="">
    window.C_CAPTCHA_IMPLEMENTATION = 'RECAPTCHA';
</script><script nonce="">
    window.C_CAPTCHA_KEY = '6Ldk59waAAAAAMPqkICbJjfMivZLCGtTpa6Wn6zO';
</script></head><body><div id="root"><section id="page-1" style="position:relative;overflow:hidden;display:grid;align-items:center;grid-template-columns:auto 100rem auto;z-index:0;"><div id="ejaCnj6HaBByHQC5" style="grid-area:1 / 1 / 2 / 4;display:grid;position:absolute;min-height:100%;min-width:100%;"><div id="bNxnjqXzmkjnccmF" style="z-index:0;"><div id="seI14xJYZWyP6SI0" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);"><div id="LzSHJkygG6Wi5drs" style="width:100%;height:100%;opacity:1.0;"><div id="rRqrO45Hki7x9bAn" style="background-color:#ffffff;opacity:1.0;transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="KWPfDn2JaS2VcDWA" style="width: 100%; height: 100.049%; top: -0.0244141%; left: 0%; transform: rotate(0deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/9115972a8e23882dd873fb8d5f299706.jpg" loading="lazy" srcset="index_files/b06c8499e4879f6b21dca0f9c247c769.jpg 768w, index_files/9115972a8e23882dd873fb8d5f299706.jpg 1728w" sizes="(max-width: 375px) 100vw, (min-width: 375.05px) and (max-width: 480px) 100vw, (min-width: 480.05px) and (max-width: 768px) 100vw, (min-width: 768.05px) and (max-width: 1024px) 100vw, (min-width: 1024.05px) 100vw" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div></div><div id="gbEFzgMldUlBMJdS" style="display:grid;position:relative;grid-area:1 / 2 / 2 / 3;"><div id="wtJcBocQDtz1QF1B"><div id="HpwppDfS4c6jER9L" style="display:grid;position:relative;grid-area:2 / 2 / 4 / 9;"><div id="SLPnGYLVt7fXAhsW" style="z-index:6;"><div id="XGMtW4tsGT5kGy5A" style="box-sizing:border-box;width:100%;height:100%;transform:rotate(0deg);"><div id="q4HXiE1veiK1R0bi" style="width:100%;height:100%;opacity:0.49;"><div id="dPiGOxC5CBy4rCnF" style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="YVSIuzBcGBdXDbXK" class="scale_rotated_fill" data-container-width="1366" data-container-height="113.66072727" data-imagebox-width="1366" data-imagebox-height="703.49" data-imagebox-top="-301.2931026" data-imagebox-left="0" data-imagebox-rotation="-180" style="width: 2560px; height: 1318.4px; top: -614.32px; left: 0px; transform: rotate(-180deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/6c634982c82399411fdc1289d1146b78.png" alt="Blue Transparent gradient fades" loading="lazy" srcset="index_files/15d69c7d92daceb5fd6ac4fb0b0976c9.png 1080w, index_files/6c634982c82399411fdc1289d1146b78.png 1800w" sizes="(max-width: 375px) 100vw, (min-width: 375.05px) and (max-width: 480px) 100vw, (min-width: 480.05px) and (max-width: 768px) 100vw, (min-width: 768.05px) and (max-width: 1024px) 100vw, (min-width: 1024.05px) 100vw" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div><div id="hyZbdyIf9yYVtIlM" style="z-index:8;"><div id="GhCy5nKpdsvPEJGp" style="padding-top:38.125%;transform:rotate(0deg);"><div id="UIkAA5YUea2YV2vl" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><div id="ZdYq7WcgqRMeRP6Y" style="width:100%;height:100%;opacity:1.0;"><div id="aGZwhfmcWdbuGwSD" style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="joeI70WlcUNpMJYQ" style="width: 100%; height: 100%; top: 0%; left: 0%; transform: rotate(0deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/d3242dc8c32da75437490c235af214c8.png" loading="lazy" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div></div></div></div><div id="uNw6v9c2I4OCExG5" style="z-index:7;"><div id="pbSv6wSdnLo9Vgik" style="padding-top:37.52%;transform:rotate(0deg);"><div id="NlqIJdW1IT4Q4AEu" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><div id="bgNwCOTsgbvU3uYl" style="width:100%;height:100%;opacity:1.0;"><div id="NlXseG5AZTpu3cTm" style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="XnPM8udHuEWZv2WB" style="width: 100%; height: 100%; top: 0%; left: 0%; transform: rotate(0deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/b2f159e087794e7e89cd5d7d20c6cca6.svg" loading="lazy" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div></div><div id="ARWsy6Ub7mQjTKU1"><div id="lo86JgckCM3k48nG" style="display:grid;position:relative;grid-area:6 / 5 / 7 / 8;"><div id="WRcs7mixzyz9JEfY" style="z-index:10;"><div id="Sy8O6R7vT0kojtII" style="box-sizing:border-box;width:100%;height:100%;"><div class="animation_container" style="width:100%;height:100%;"><div style="width:100%;height:100%;transform:rotate(0deg);"><div class="animated" style="width: 100%; height: 100%; animation: 750ms ease 100ms 1 normal both running wipe-RIGHT-7116b0ee-7e21-4ef5-9477-5ac50eca7f84;"><div id="rVuDTY2BvOJHpuqZ" style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;"><p id="RM31140YFFukPEqA" style="color:#ff6333;font-family:YAEp1FLgsF4-0;line-height:1.09151115em;letter-spacing:-0.02em;"><span id="nhziEzajDEgC8Cjk" style="color:#ff6333;font-weight:700;">The Venafi Control Plane</span><br></p></div></div></div></div></div></div><div id="UkIErEewEIN7zxtk" style="z-index:11;"><div id="wC70GHU6PrMli2JY" style="box-sizing:border-box;width:100%;height:100%;"><div class="animation_container" style="width:100%;height:100%;"><div style="width:100%;height:100%;transform:rotate(0deg);"><div class="animated" style="width: 100%; height: 100%; animation: 750ms ease 100ms 1 normal both running wipe-RIGHT-a0f32f33-7085-46ac-9f53-6c26e04e4b9e;"><div id="UjDkFJSRDlk7iExs" style="opacity:1.0;display:flex;box-sizing:border-box;flex-direction:column;justify-content:flex-start;width:100%;height:100%;"><p id="ssHcvm57c4k7sGFK" style="color:#ffffff;font-family:YAEp1FLgsF4-0;line-height:1.17416037em;text-align:center;"><span id="dNWJLtWPMaUf7Ncd" style="color:#ffffff;font-weight:700;">The World Leader in Machine Identity Management</span><br></p><p id="yK42fYBidfOo7R7k" style="color:#ffffff;direction:ltr;font-family:YAEp1FLgsF4-0;margin-left:0em;line-height:1.17416037em;text-align:center;text-transform:none;white-space:pre;"><br></p></div></div></div></div></div></div></div></div><div id="p0KEX1uxIUTFd0aJ"><div id="zEeMDi2gxAE2fw8f" style="display:grid;position:relative;grid-area:8 / 4 / 9 / 7;"><div id="pUeRJlhGl3BXjyvz" style="z-index:1;"><div id="bbXcM4p55yLtrXGu" style="padding-top:747.21870998%;"><div id="vPqmbpRKVskg2OgN" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><div class="animation_container" style="width:100%;height:100%;"><div class="animated" style="width: 100%; height: 100%; animation: 5000ms ease 100ms 1 normal both running breathe-RIGHT-4f6e5b1d-2ac8-46c9-837b-a48731484306;"><div style="width:100%;height:100%;transform:rotate(90deg);"><svg id="aVsOO7hy2sK7Ht9V" viewBox="0 0 52.0 388.5537" style="width:100%;height:100%;opacity:0.68;overflow:hidden;position:absolute;top:0%;left:0%;background:url('');"><g id="LmZgFtxKovFJqg7T" style="transform:scale(1, 1);"><path id="tcLrYxi4mPLwRuOq" d="M42.19999389648437,388.55372613526123 L9.800000190734863,388.55372613526123 C4.400000095367432,388.55372613526123 0.0,384.15373223877685 0.0,378.7537230835034 L0.0,9.800000190734863 C0.0,4.400000095367432 4.400000095367432,0.0 9.800000190734863,0.0 L42.200009155273435,0.0 C47.60000305175781,0.0 52.00001220703125,4.400000095367432 52.00001220703125,9.800000190734863 L52.00001220703125,378.7537383422925 C52.00001220703125,384.15373223877685 47.60000305175781,388.5537413940503 42.200009155273435,388.5537413940503" style="fill:#ffffff;opacity:1.0;"></path></g></svg></div></div></div></div></div></div><div id="WaVP7Y3VDg20AlM0" style="z-index:3;"><div id="T8Qh1cktevKkwcmc" style="padding-top:14.69387755%;transform:rotate(0deg);"><div id="WFr2XIa7MN5PhTjj" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><div id="LJHlHHOPTV4nNPFC" style="width:100%;height:100%;opacity:1.0;"><div id="O4VJrKTWqXgdaGu4" style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="vx7Et6oQa9xyk34N" style="width: 100%; height: 100%; top: 0%; left: 0%; transform: rotate(0deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/7a67eb933ffb251ca80d087529e997e3.svg" loading="lazy" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div></div><div id="cecPwCtAY1v73YAY" style="z-index:5;"><div id="mcGbjlhSot44STxk" style="padding-top:18.3011583%;transform:rotate(0deg);"><div id="DnaUe3HbJSZX0JJO" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><div id="jbmW0Cnih0grn4KP" style="width:100%;height:100%;opacity:1.0;"><div id="wfOmSkWaajpK7B8k" style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="dEi6oMH8VNhSXBVJ" style="width: 100%; height: 100%; top: 0%; left: 0%; transform: rotate(0deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/30ac1f79f9fd136c28749771359c3abc.svg" loading="lazy" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div></div><div id="zbNaYWBcZDf8Qapn" style="z-index:4;"><div id="oGZAYvF2pNtxTNzv" style="padding-top:19.47097722%;transform:rotate(0deg);"><div id="sVXWEsRPbCGk5Qmw" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><div id="hgKgtlIDMPga0aBM" style="width:100%;height:100%;opacity:1.0;"><div id="mXfVU3c9jYvbLdQw" style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="iU96mVjx34PxdcED" style="width: 100%; height: 100%; top: 0%; left: 0%; transform: rotate(0deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/ff3952ada9b67b976581050b254c7768.svg" loading="lazy" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div></div><div id="t4VZOlJbFtyMV50z" style="z-index:2;"><div id="ly5euXyj2DKPegVv" style="padding-top:41.93548387%;transform:rotate(0deg);"><div id="vWWQ5CuscTnrcPg8" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"><div id="fUlU5EmpqUVGy4HQ" style="width:100%;height:100%;opacity:1.0;"><div id="b6BzrBtUdA6Q0qPd" style="transform:scale(1, 1);width:100%;height:100%;overflow:hidden;position:relative;"><div id="DylQQBB1P4USlAcE" style="width: 100%; height: 100%; top: 0%; left: 0%; transform: rotate(0deg); position: absolute; opacity: 1; animation: 0s ease 0s 1 normal none running none;"><img src="index_files/cac7f9ae714fc12c7e23a2a0fe54bb3e.svg" loading="lazy" style="width:100%;height:100%;display:block;object-fit:cover;"></div></div></div></div></div></div></div></div></div></section><script src="index_files/939898b427480d700449229ff00dbb8a6f9f77442b532f697866e6914ab88.js" async="" nonce=""></script><script src="index_files/416dba4c1127c057d1819fedcb3a4797fc302d164296a52ae7ff9f38f3815.js" async="" nonce=""></script><script src="index_files/8a6dfbac9d5e968445939cbb2698c0f199ddf95f386d464475f80f04331fb.js" async="" nonce=""></script></div><script nonce="">
  const lang = navigator.language ? navigator.language : 'en';
  fetch('_footer?lang=' + encodeURIComponent(lang)).then(response => {
    if (response.status !== 200) {
      return;
    }
    response.text().then(footerStr => {
      const div = document.createElement('div');
      div.innerHTML = footerStr;
      for (const child of [...div.children]) {
        if (child.tagName.toLowerCase() !== 'script') {
          document.body.append(child);
        }
      }

      (() => { !function(e){"use strict";const t=document.getElementById("modal_backdrop"),n=document.getElementById("modal"),o=document.getElementById("captcha-form"),c=document.getElementById("report_button"),d=document.getElementById("form_report"),s=document.getElementById("form_cancel"),l=document.getElementById("form_submit_reason"),a=document.getElementById("form_go_back"),m=document.getElementById("form_submit_captcha"),r=document.getElementById("form_close"),i=document.getElementById("report_reason_0"),u=document.getElementById("error_message"),p=document.getElementById("error_message_captcha"),_=new Map;_.set(0,document.getElementById("form_step_terms")),_.set(1,document.getElementById("form_step_report_reason")),_.set(4,document.getElementById("form_step_report_other"));const y=document.getElementById("form_step_report_ip");y&&_.set(5,y),_.set(2,document.getElementById("form_step_captcha")),_.set(3,document.getElementById("form_step_success"));const E=document.getElementById("report_reason_4"),f=document.getElementById("form_close_ip"),g=document.getElementById("form_go_back_ip"),h=document.getElementById("report_reason_other"),I=document.getElementById("form_close_other"),k=document.getElementById("form_go_back_other");function v(){t.classList.remove("active"),n.classList.remove("active"),c.classList.remove("active"),c.focus()}function B(e){_.forEach(((t,n)=>{n===e?(t.style.display="block",A(t)):t.style.display="none"}))}let w,b=!1;const T="NETEASE"===window.C_CAPTCHA_IMPLEMENTATION?()=>w:()=>{const e=o.elements.namedItem("g-recaptcha-response");return null==e?void 0:e.value};t.onclick=v,s.onclick=v,r.onclick=v,f&&(f.onclick=v),I.onclick=v,c.onclick=function(){_.forEach(((e,t)=>{e.style.display=0===t?"block":"none"})),t.classList.add("active"),n.classList.add("active"),c.classList.add("active"),i.checked=!0,setTimeout((()=>{A(_.get(0))}),350)},d.onclick=()=>B(1),l.onclick=()=>{null!=y&&E.checked?B(5):h.checked?B(4):(B(2),function(){if(b)return;const e=document.createElement("script");e.src="NETEASE"===window.C_CAPTCHA_IMPLEMENTATION?"https://cstaticdun.126.net/load.min.js":"https://www.google.com/recaptcha/api.js",e.async=!0,e.defer=!0,document.head.appendChild(e),b=!0,e.onload="NETEASE"===window.C_CAPTCHA_IMPLEMENTATION?()=>{var e;null===(e=window.initNECaptcha)||void 0===e||e.call(window,{captchaId:window.C_CAPTCHA_KEY,element:"#netease-captcha",protocol:"https",width:"auto",onVerify:(e,t)=>{w=t.validate}})}:()=>{}}())},a.onclick=()=>B(1),g&&(g.onclick=()=>B(1)),k.onclick=()=>B(1),o.addEventListener("submit",(function(e){e.preventDefault(),u.style.display="none",p.style.display="none";const t=function(){let e="";const t=document.getElementsByName("report_reason");for(let n=0;n<t.length;n++){const o=t[n];o.checked&&(e=o.value)}return e}(),n=T();if(!n)return void(p.style.display="block");const o={reason:t,challenge:n},c=window.location.origin+window.location.pathname+"/_api/report";m.classList.add("loading"),fetch(c,{method:"POST",body:JSON.stringify(o),headers:{"Content-Type":"application/json; charset=utf-8"}}).then((e=>{m.classList.remove("loading"),e.ok?B(3):u.style.display="block"}))}));const C=new Map,A=e=>{const t=C.get(e);null!=t&&document.removeEventListener("keydown",t);const n=e.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'),o=e,c=n[n.length-1],d=function(e){("Tab"===e.key||9===e.keyCode)&&(e.shiftKey?document.activeElement===o&&(c.focus(),e.preventDefault()):document.activeElement===c&&(o.focus(),e.preventDefault()))};C.set(e,d),document.addEventListener("keydown",d),o.focus()};e.keepFocus=A,Object.defineProperty(e,"__esModule",{value:!0})}({}); })();
      window.dispatchEvent(new Event('resize'));
    });
  });
</script><style>
    .footer-overflow-container {
        overflow-x: auto;
        display: flex;
        background-color: #000000;
    }

    .footer-container {
        flex-grow: 1;
        position: relative;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        padding: 16px;
    }

    .footer-pill-link {
        appearance: none;
        text-decoration: none;
    }

    .footer-pill {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        border-radius: 1000px;
        border: none;
        background: none;
        padding: 8px 12px;
        font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Helvetica, Arial, sans-serif;
        white-space: nowrap;
        text-decoration: none;
        font-weight: 600;
        font-style: normal;
        font-size: calc(13px * var(--rfso, var(--bfso, 1)));
        color: #ffffff;
        transition: background-color 0.2s;
    }
    .footer-pill:hover {
        cursor: pointer;
    }
    .footer-pill + .footer-pill {
        margin-left: 8px;
    }

    .footer-pill-primary {
        position: relative;
        z-index: 1;
        background-color: rgba(255, 255, 255, 0.1);
    }

    .footer-pill-primary:hover > .footer-pill-primary-background {
        opacity: 1;
    }

    .footer-pill-primary-background {
        position: absolute;
        z-index: -1;
        border-radius: 1000px;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, #00C4CC 0%, #7D2AE8 100%);
        opacity: 0;
        overflow: hidden;
        transition: opacity 0.2s;
    }

    /* Subtle wipe effect */
    .footer-pill-primary-background::after {
        content: "";
        position: absolute;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        background: linear-gradient(to right, rgba(125, 42, 232, 0) 0%, #1a1a1a calc(50px + 20%), #1a1a1a 100%);
        transform: translateX(0);
        transition: transform 0.7s;
    }
    .footer-pill-primary:hover > .footer-pill-primary-background::after {
        transform: translateX(110%);
    }

    .footer-pill-primary-background > svg {
        position: absolute;
        top: 50%;
        left: 0;
        right: 0;
        transform-origin: center;
        transform: translateY(-50%);
        width: 100%;
    }

    .animation-container {
        animation: spin linear 12s infinite;
        animation-play-state: paused;
    }
    .footer-pill-primary:hover > .footer-pill-primary-background .animation-container {
        animation-play-state: running;
    }

    .footer-pill-secondary {
        background-color: rgba(255, 255, 255, 0);
    }
    .footer-pill-secondary:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }
    .footer-pill-secondary:active, .footer-pill-secondary.active {
        background-color: rgba(255, 255, 255, 0.15)
    }

    .inline-icon {
        display: inline-block;
        width: 16px;
        height: 16px;
        margin-right: 5px;
    }
    .inline-icon > svg {
        fill: rgba(218, 218, 218, 1);
    }

    .inline-icon-logo {
        display: inline-block;
        height: 16px;
        margin-left: 5px;
    }
    .inline-icon-logo > svg {
        height: 100%;
    }

    .modal-backdrop {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 9999;
        transition: opacity 0.35s, visibility 0.35s;
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
    }
    .modal-backdrop.active {
        opacity: 1;
        visibility: visible;
        pointer-events: all;
    }

    .report-form-modal {
        display: block;
        box-sizing: border-box;
        position: absolute;
        left: 16px;
        width: 367px; /* min width for the gcaptcha to fit*/
        transform: translate3d(0, calc(-100% + 24px), 0);
        z-index: 10000;
        font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Helvetica, Arial, sans-serif;
        background-color: #ffffff;
        border-radius: 8px;
        margin: 0;
        box-shadow: 0px 2px 18px 0px rgba(14, 19, 24, 0.25), 0px 0px 1px 0px rgba(14, 19, 24, 0.02);
        transition-duration: 0.35s;
        transition-property: opacity, transform, visibility;
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
    }
    .report-form-modal.active {
        transform: translate3d(0, calc(-100% + 8px), 0);
        opacity: 1;
        visibility: visible;
        pointer-events: all;
    }

    .form-content {
        margin: 32px;
        outline-offset: 34px;
    }

    .form-content > * {
        margin: 16px 0;
    }

    .form-title {
        font-size: calc(24px * var(--rfso, var(--bfso, 1)));
        font-weight: 700;
    }

    .form-body {
        font-size: calc(14px * var(--rfso, var(--bfso, 1)));
        font-weight: 400;
        color: rgba(14, 19, 24, 0.7);
    }

    .form-body-bold {
        font-size: calc(14px * var(--rfso, var(--bfso, 1)));
        font-weight: 600;
        line-height: 22.4px;
        color: rgba(14, 19, 24, 1);
    }

    .form-radio-input {
        display: grid;
        grid-template-columns: 24px auto;
        grid-template-rows: auto;
        grid-template-areas:
          "radio-button radio-label"
          ". radio-description"
    }
    .form-radio-input:hover {
        cursor: pointer;
    }

    .radio-button-input {
        opacity: 0;
        margin: 0;
        width: 0;
        height: 0;
    }

    .radio-button {
        align-self: flex-start;
        grid-area: radio-button;
        display: inline-block;
        width: 16px;
        height: 16px;
        margin: 4px 8px 0 0;
        vertical-align: middle;
        border-radius: 50%;
        box-shadow: inset 0 0 0 1px rgba(53, 71, 90, .2);
        outline: none;
        background-color: #ffffff;
        flex-shrink: 0;
    }
    .radio-button-input:checked + .radio-button {
        background: #fff;
        box-shadow: inset 0 0 0 5px #8b3dff;
        transition: box-shadow .1s ease-in-out, background-color .1s ease-in-out;
    }
    .form-radio-input:hover .radio-button-input:not(:checked) + .radio-button {
        box-shadow: inset 0 0 0 1px rgba(30, 41, 51, .45);
    }

    .radio-button-input + .radio-button::after {
        content: "";
        width: 6px;
        height: 6px;
        background-color: transparent;
        display: block;
        margin: 5px;
        border-radius: 50%;
    }
    .radio-button-input:checked + .radio-button::after {
        background-color: #ffffff;
        transition: background-color .1s ease-in-out;
    }

    .form-radio-label {
        grid-area: radio-label;
        font-size: calc(14px * var(--rfso, var(--bfso, 1)));
        font-weight: 600;
        line-height: 22.4px;
        color: rgba(14, 19, 24, 1);
    }

    .form-radio-desc {
        grid-area: radio-description;
        font-size: calc(12px * var(--rfso, var(--bfso, 1)));
        font-weight: 400;
        color: rgba(14, 19, 24, 0.7);
        margin: 0;
    }

    .g-recaptcha {
        width: 300px;
    }

    .form-buttons {
        margin-top: 32px;
        display: grid;
        grid-gap: 8px;
        grid-template-columns: auto auto;
        justify-content: flex-end;
    }

    .button {
        border: 2px solid transparent;
        box-sizing: border-box;
        background-color: rgba(64, 87, 109, 0.07);
        border-radius: 4px;
        color: #0e1318;
        cursor: pointer;
        display: inline-flex;
        height: 40px;
        margin: 0;
        max-width: 100%;
        min-width: 80px;
        width: 100%;
        padding: 0 6px;
        vertical-align: middle;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Helvetica, Arial, sans-serif;
        font-weight: 400;
        line-height: 1.6;
        outline-offset: 2px;
        transition: background-color 0.2s;
    }
    .button:hover {
        background-color: rgba(57, 76, 96, .15);
    }
    .button:active {
        background-color: rgba(53, 71, 90, .2);
    }

    .submit-button {
        border: 2px solid transparent;
        box-sizing: border-box;
        background-color: #7d2ae8;
        border-radius: 4px;
        color: #ffffff;
        cursor: pointer;
        display: inline-flex;
        height: 40px;
        margin: 0;
        max-width: 100%;
        min-width: 80px;
        width: 100%;
        padding: 0 6px;
        vertical-align: middle;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Helvetica, Arial, sans-serif;
        font-weight: 400;
        line-height: 1.6;
        outline-offset: 4px;
        transition: background-color 0.2s;
    }
    .submit-button:hover {
        background-color: #8d39fa;
    }
    .submit-button:active {
        background-color: #6718cf;
    }

    .button-text {
        font-size: calc(14px * var(--rfso, var(--bfso, 1)));
        display: inline-block;
        max-width: 100%;
        overflow: hidden;
        padding: 0 8px;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-weight: 600;
        transition: all 0.2s;
    }
    .submit-button.loading .button-text {
        visibility: hidden;
        opacity: 0;
    }

    .submit-button.loading::after {
        content: "";
        position: absolute;
        width: 16px;
        height: 16px;
        margin: auto;
        border: 4px solid transparent;
        border-top-color: #ffffff;
        border-radius: 50%;
        animation: spin 1s ease infinite;
    }

    .text-danger {
        text-align: left;
        margin: 4px 0 0;
        color: #f84856;
        font-size: calc(12px * var(--rfso, var(--bfso, 1)));
    }

    .a-link:visited {
        color: rgba(14, 19, 24, 0.7)
    }
    .a-link {
        text-decoration: underline;
        color: rgba(14, 19, 24, 0.7)
    }
    .a-link:hover {
        color: #7d2ae8;
    }

    @keyframes spin {
        from {
            transform: rotate(0turn);
        }

        to {
            transform: rotate(1turn);
        }
    }

    @supports selector(:focus-visible) {
        .radio-button-input:focus-visible + .radio-button {
            outline: auto;
        }

        .footer-pill-primary:focus-visible > .footer-pill-primary-background::after {
            transform: translateX(110%);
        }

        .footer-pill-primary:focus-visible > .footer-pill-primary-background {
            opacity: 1;
        }

        .footer-pill-primary:focus-visible > .footer-pill-primary-background .animation-container {
            animation-play-state: running;
        }
    }

    @supports not selector(:focus-visible) {
        .radio-button-input:focus + .radio-button {
            outline: auto;
        }

        .footer-pill-primary:focus > .footer-pill-primary-background::after {
            transform: translateX(110%);
        }

        .footer-pill-primary:focus > .footer-pill-primary-background {
            opacity: 1;
        }

        .footer-pill-primary:focus > .footer-pill-primary-background .animation-container {
            animation-play-state: running;
        }
    }

    /* stylelint-disable-next-line media-feature-name-disallowed-list */
    @media only screen and (max-width: 600px) {
        .modal-backdrop {
            background-color: rgba(14, 19, 24, 0.45);
            backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px);
        }

        .report-form-modal {
            width: 100%;
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 8px 8px 0 0;
            transform: translate3d(0, 33%, 0);
        }

        .report-form-modal.active {
            transform: translate3d(0, 0, 0);
        }

        .form-content {
            margin: 16px;
        }

        .form-buttons {
            display: grid;
            grid-gap: 8px;
            grid-template-columns: 1fr;
        }

        .submit-button {
            order: -1;
        }

        @supports (padding: env(safe-area-inset-bottom)) {
            .footer-container {
                padding: 16px 16px calc(16px + env(safe-area-inset-bottom)) 16px;
            }

            .form-content {
                margin: 16px 16px calc(16px + env(safe-area-inset-bottom)) 16px;
            }
        }
    }
    @media (prefers-reduced-motion) {
        .report-form-modal, .report-form-modal.active {
            transition-property: opacity, visibility;
            transform: translate3d(0, calc(-100% + 8px), 0);
        }
        @media only screen and (max-width: 600px) {
            .report-form-modal, .report-form-modal.active {
                transform: translate3d(0, 0, 0);
            }
        }
        .animation-container {
            animation-play-state: paused !important;
        }
        .footer-pill-primary-background::after {
            transform: translateX(0);
            opacity: 0;
            transition: opacity 0.7s;
        }
        .footer-pill-primary-background > svg {
            display: none;
        }
    }
</style><div class="footer-overflow-container" lang="en">
  <div class="footer-container">
    <button id="report_button" class="footer-pill footer-pill-secondary" type="button">
      Terms &amp; Support
    </button>
    <a class="footer-pill footer-pill-primary footer-pill-link" target="_blank" href="https://www.canva.com/" aria-label="Designed with Canva">
      <div class="footer-pill-primary-background">
        <svg viewBox="20 20 55 55" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="cyanSpotLarge" cx="0.5" cy="0.5" r="0.5" fx="0.8" fy="0.8" spreadMethod="pad">
              <stop offset="0%" stop-color="rgb(0, 196, 204)" stop-opacity="1"></stop>
              <stop offset="100%" stop-color="rgb(0, 196, 204)" stop-opacity="0"></stop>
            </radialGradient>
            <radialGradient id="cyanSpot" cx="0.5" cy="0.5" r="0.5" fx="0.2" fy="0.2" spreadMethod="pad">
              <stop offset="0%" stop-color="rgb(0, 196, 204)" stop-opacity="0.75"></stop>
              <stop offset="100%" stop-color="rgb(0, 196, 204)" stop-opacity="0"></stop>
            </radialGradient>
            <radialGradient id="purpleSpotLarge" cx="0.5" cy="0.5" r="0.5" fx="0.8" fy="0.8" spreadMethod="pad">
              <stop offset="0%" stop-color="rgb(125, 42, 232)" stop-opacity="1"></stop>
              <stop offset="100%" stop-color="rgb(125, 42, 232)" stop-opacity="0"></stop>
            </radialGradient>
            <radialGradient id="purpleSpot" cx="0.5" cy="0.5" r="0.5" fx="0.2" fy="0.2" spreadMethod="pad">
              <stop offset="0%" stop-color="rgb(125, 42, 232)" stop-opacity="0.85"></stop>
              <stop offset="100%" stop-color="rgb(125, 42, 232)" stop-opacity="0"></stop>
            </radialGradient>
          </defs>
          <!-- Average the RGB values of the Cyan & Purple brand colors -> Blue rect background -->
          <rect x="0" y="0" width="100" height="100" fill="rgb(62.5, 119, 218)"></rect>
          <g class="animation-container">
            <!-- Initial Rotation -->
            <g transform="rotate(25)">
              <!-- Large Spots -->
              <g transform="rotate(0) scale(2) translate(-40, -40)">
                <rect x="0" y="0" width="100" height="100" fill="url(#cyanSpotLarge)"></rect>
              </g>
              <g transform="rotate(180) scale(2) translate(-40, -40)">
                <rect x="0" y="0" width="100" height="100" fill="url(#cyanSpotLarge)"></rect>
              </g>
              <g transform="rotate(90) scale(1.5) translate(-25, -25)">
                <rect x="0" y="0" width="100" height="100" fill="url(#purpleSpotLarge)"></rect>
              </g>
              <g transform="rotate(270) scale(1.5) translate(-25, -25)">
                <rect x="0" y="0" width="100" height="100" fill="url(#purpleSpotLarge)"></rect>
              </g>
              <!-- Small spots -->
              <g transform="rotate(0) translate(-10, -10)">
                <rect x="0" y="0" width="66" height="66" fill="url(#purpleSpot"></rect>
              </g>
              <g transform="rotate(180) translate(-10, -10)">
                <rect x="0" y="0" width="66" height="66" fill="url(#purpleSpot"></rect>
              </g>
              <g transform="rotate(90) scale(1.2) translate(-10, -10)">
                <rect x="0" y="0" width="66" height="66" fill="url(#cyanSpot)"></rect>
              </g>
              <g transform="rotate(270) scale(1.2) translate(-10, -10)">
                <rect x="0" y="0" width="66" height="66" fill="url(#cyanSpot)"></rect>
              </g>
            </g>
          </g>
        </svg>
      </div>
      Designed with 
      <span class="inline-icon-logo">
        <svg viewBox="0 0 80 30" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M79.444 18.096c-.136 0-.26.088-.324.272-.82 2.34-1.928 3.732-2.84 3.732-.524 0-.736-.584-.736-1.5 0-2.292 1.372-7.152 2.064-9.368.08-.268.132-.508.132-.712 0-.644-.352-.96-1.224-.96-.94 0-1.952.368-2.936 2.092-.34-1.52-1.368-2.184-2.804-2.184-1.66 0-3.264 1.068-4.584 2.8-1.32 1.732-2.872 2.3-4.04 2.02.84-2.056 1.152-3.592 1.152-4.732 0-1.788-.884-2.868-2.312-2.868-2.172 0-3.424 2.072-3.424 4.252 0 1.684.764 3.416 2.444 4.256-1.408 3.184-3.464 6.064-4.244 6.064-1.008 0-1.304-4.932-1.248-8.46.036-2.024.204-2.128.204-2.74 0-.352-.228-.592-1.144-.592-2.136 0-2.796 1.808-2.896 3.884a10.233 10.233 0 01-.368 2.332c-.892 3.184-2.732 5.6-3.932 5.6-.556 0-.708-.556-.708-1.284 0-2.292 1.284-5.156 1.284-7.6 0-1.796-.788-2.932-2.272-2.932-1.748 0-4.06 2.08-6.248 5.976.72-2.984 1.016-5.872-1.116-5.872A2.886 2.886 0 0036 9.916a.752.752 0 00-.432.728c.204 3.176-2.56 11.312-5.18 11.312-.476 0-.708-.516-.708-1.348 0-2.296 1.368-7.144 2.056-9.364.088-.288.136-.536.136-.752 0-.608-.376-.92-1.228-.92-.936 0-1.952.356-2.932 2.08-.344-1.52-1.372-2.184-2.808-2.184-2.356 0-4.988 2.492-6.144 5.74-1.548 4.336-4.668 8.524-8.868 8.524-3.812 0-5.824-3.172-5.824-8.184C4.068 8.312 9.38 2.4 13.32 2.4c1.884 0 2.784 1.2 2.784 3.04 0 2.228-1.244 3.264-1.244 4.112 0 .26.216.516.644.516 1.712 0 3.728-2.012 3.728-4.756S17.004.56 13.064.56C6.552.56 0 7.112 0 15.508c0 6.68 3.296 10.708 8.996 10.708 3.888 0 7.284-3.024 9.116-6.552.208 2.924 1.536 4.452 3.56 4.452 1.8 0 3.256-1.072 4.368-2.956.428 1.972 1.564 2.936 3.04 2.936 1.692 0 3.108-1.072 4.456-3.064-.02 1.564.336 3.036 1.692 3.036.64 0 1.404-.148 1.54-.708 1.428-5.904 4.956-10.724 6.036-10.724.32 0 .408.308.408.672 0 1.604-1.132 4.892-1.132 6.992 0 2.268.964 3.768 2.956 3.768 2.208 0 4.452-2.704 5.948-6.656.468 3.692 1.48 6.672 3.064 6.672 1.944 0 5.396-4.092 7.488-8.424.82.104 2.052.076 3.236-.76-.504 1.276-.8 2.672-.8 4.068 0 4.02 1.92 5.148 3.572 5.148 1.796 0 3.252-1.072 4.368-2.956.368 1.7 1.308 2.932 3.036 2.932 2.704 0 5.052-2.764 5.052-5.032 0-.6-.256-.964-.556-.964zM23.32 21.888c-1.092 0-1.52-1.1-1.52-2.74 0-2.848 1.948-7.604 4.008-7.604.9 0 1.24 1.06 1.24 2.356 0 2.892-1.852 7.988-3.728 7.988zm37.404-8.5c-.652-.776-.888-1.832-.888-2.772 0-1.16.424-2.14.932-2.14s.664.5.664 1.196c0 1.164-.416 2.864-.708 3.716zm8.468 8.5c-1.092 0-1.52-1.264-1.52-2.74 0-2.748 1.948-7.604 4.024-7.604.9 0 1.22 1.052 1.22 2.356 0 2.892-1.82 7.988-3.724 7.988z" fill="#fff"></path>
        </svg>
      </span>
      
    </a>
  </div>
  <div id="modal_backdrop" class="modal-backdrop"></div>
  <div id="modal" class="report-form-modal" role="dialog">
    <div class="form-content" id="form_step_terms" style="display: block;" aria-labelledby="termsTitle" aria-describedby="termsDesc" tabindex="0">
      <h2 id="termsTitle" class="form-title">Terms &amp; Support</h2>
      <p id="termsDesc" class="form-body">This website has been created with Canva, but the content is User Content that is subject to our <a class="a-link" href="https://www.canva.com/policies/terms-of-use/" target="_blank">Terms of Use</a>. If you see anything that breaches our <a class="a-link" href="https://www.canva.com/policies/acceptable-use-policy/" target="_blank">acceptable use policy</a>, please report it to our content review team.</p>
      <div class="form-buttons">
        <button id="form_report" type="button" class="button">
          <span class="button-text">
            Report
          </span>
        </button>
      </div>
    </div>
    <div class="form-content" id="form_step_report_reason" style="display: none;" aria-labelledby="reportTitle" aria-describedby="reportDesc" tabindex="0">
      <h2 id="reportTitle" class="form-title">Report</h2>
      <p id="reportDesc" class="form-body">Reporting helps Canva ensure its content is appropriate and correctly
labelled.</p>
      <p class="form-body-bold">Why are you reporting this content?</p>
      <label class="form-radio-input" for="report_reason_0">
        <input id="report_reason_0" class="radio-button-input" type="radio" name="report_reason" value="0" autocomplete="off" checked="checked">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Inappropriate content
        </span>
      </label>
      <label class="form-radio-input" for="report_reason_1">
        <input id="report_reason_1" class="radio-button-input" type="radio" name="report_reason" value="1" autocomplete="off">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Hateful speech, activities or discrimination
        </span>
      </label>
      <label class="form-radio-input" for="report_reason_2">
        <input id="report_reason_2" class="radio-button-input" type="radio" name="report_reason" value="2" autocomplete="off">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Illegal content
        </span>
      </label>
      <label class="form-radio-input" for="report_reason_3">
        <input id="report_reason_3" class="radio-button-input" type="radio" name="report_reason" value="3" autocomplete="off">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Defamation or harassment
        </span>
      </label>
      <label class="form-radio-input" for="report_reason_4">
        <input id="report_reason_4" class="radio-button-input" type="radio" name="report_reason" value="4" autocomplete="off">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Intellectual Property infringement
        </span>
      </label>
      <label class="form-radio-input" for="report_reason_5">
        <input id="report_reason_5" class="radio-button-input" type="radio" name="report_reason" value="5" autocomplete="off">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Misinformation
        </span>
      </label>
      <label class="form-radio-input" for="report_reason_6">
        <input id="report_reason_6" class="radio-button-input" type="radio" name="report_reason" value="6" autocomplete="off">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Phishing
        </span>
      </label>
      <label class="form-radio-input" for="report_reason_other">
        <input id="report_reason_other" class="radio-button-input" type="radio" name="report_reason" value="7" autocomplete="off">
        <span class="radio-button"></span>
        <span class="form-radio-label">
          Something else
        </span>
      </label>
      <div class="form-buttons">
        <button id="form_cancel" type="button" class="button">
          <span class="button-text">Cancel</span>
        </button>
        <button id="form_submit_reason" type="button" class="submit-button">
          <span class="button-text">Next</span>
        </button>
      </div>
    </div>
    <div class="form-content" id="form_step_report_ip" style="display: none;" aria-labelledby="ipTitle" aria-describedby="ipDesc" tabindex="0">
      <h2 id="ipTitle" class="form-title">Intellectual Property infringement</h2>
      <p id="ipDesc" class="form-body">Please submit an infringement notice to Canva by following the steps in our <a class="a-link" href="https://www.canva.com/policies/intellectual-property-policy/" target="_blank">Intellectual Property Policy</a>.</p>
      <div class="form-buttons">
        <button id="form_go_back_ip" type="button" class="button">
          <span class="button-text">Back</span>
        </button>
        <button id="form_close_ip" type="button" class="submit-button">
          <span class="button-text">Close</span>
        </button>
      </div>
    </div>
    <div class="form-content" id="form_step_report_other" style="display: none;" aria-labelledby="otherTitle" aria-describedby="otherDesc" tabindex="0">
      <h2 id="otherTitle" class="form-title">Something else</h2>
      <p id="otherDesc" class="form-body">Please contact Canva at <a class="a-link" href="mailto:privacy@canva.com" target="_blank">privacy@canva.com</a> and include the website URL to report other concerns.</p>
      <div class="form-buttons">
        <button id="form_go_back_other" type="button" class="button">
          <span class="button-text">Back</span>
        </button>
        <button id="form_close_other" type="button" class="submit-button">
          <span class="button-text">Close</span>
        </button>
      </div>
    </div>
    <div class="form-content" id="form_step_captcha" style="display: none;" aria-labelledby="captchaTitle" aria-describedby="captchaDesc" tabindex="0">
      <h2 id="captchaTitle" class="form-title">Report</h2>
      <p id="captchaDesc" class="form-body">Let's just make sure you're human.</p>
      <form id="captcha-form">
        <div class="g-recaptcha" data-sitekey="6Ldk59waAAAAAMPqkICbJjfMivZLCGtTpa6Wn6zO"></div>
        <div id="netease-captcha"></div>
        <p id="error_message_captcha" class="text-danger" style="display: none;">
          Please complete the verification.
        </p>
        <p id="error_message" class="text-danger" style="display: none;">
          We weren't able to submit your report right now. Please try again later.
        </p>
        <div class="form-buttons">
          <button id="form_go_back" type="button" class="button">
            <span class="button-text">Back</span>
          </button>
          <button id="form_submit_captcha" type="submit" class="submit-button">
            <span class="button-text">Submit</span>
          </button>
        </div>
      </form>
    </div>
    <div class="form-content" id="form_step_success" style="display: none;" aria-labelledby="thanksTitle" aria-describedby="thanksDesc" tabindex="0">
      <h2 id="thanksTitle" class="form-title">Thank you</h2>
      <p id="thanksDesc" class="form-body">Thanks for flagging this content as inappropriate. Our content review team is on it and will review as soon as possible.</p>
      <div class="form-buttons">
        <button id="form_close" type="button" class="submit-button">
          <span class="button-text">
            Close
          </span>
        </button>
      </div>
    </div>
  </div>
</div></body></html>